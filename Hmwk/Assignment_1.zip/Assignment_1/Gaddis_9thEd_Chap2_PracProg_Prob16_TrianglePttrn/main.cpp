/* 
 * File:   main.cpp
 * Author: Mehak
 * Created on January 13, 2023, 6:20 PM
 * Purpose: Create a Triangle Pattern
 */

// System Libraries
#include <iostream> // Input Output Library 
using namespace std;

//User Libraries

//Global Constants not Variables
//Science, Math, Conversions, Dimensions

//Function Prototypes

//Execution begins here at main
int main(int argc, char** argv) {
    //Set random number seed
    
    //Declare Variables
    
    //Using asterisk to create Triangle Pattern
    
    //Initialize Variables
    cout<<"   "<<"*"<<"   "<<endl;
    cout<<"  "<<"***"<<"  "<<endl;
    cout<<" "<<"*****"<<" "<<endl;
    cout<<"*******"<<endl;
    
    //Map/Process the inputs -> Outputs
    
    //Display Inputs/Outputs
    
    //Clean up memory and files
    
    //Exit Program
    return 0;
}