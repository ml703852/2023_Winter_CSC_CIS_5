/* 
 * File:   main.cpp
 * Author: Mehak
 * Created on January 10, 2023, 5:43 PM
 * Purpose: Sum of Two Numbers
 */

// System Libraries
#include <iostream> // Input Output Library 
using namespace std;

//User Libraries

//Global Constants not Variables
//Science, Math, Conversions, Dimensions

//Function Prototypes

//Execution begins here at main
int main(int argc, char** argv) {
    //Set random number seed
    
    //Declare Variables
    int fifty = 50,
            one_hun = 100,
    
    //Initialize Variables
    
    //Map/Process the inputs -> Outputs
    total = fifty + one_hun;   //Calculate value of total
    
    //Display Inputs/Outputs
    cout<<"Total = "<<total<<endl;
    
    //Clean up memory and files
    
    //Exit Program
    return 0;
}