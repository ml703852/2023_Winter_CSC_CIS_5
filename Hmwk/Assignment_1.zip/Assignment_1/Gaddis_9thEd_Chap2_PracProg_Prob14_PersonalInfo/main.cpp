/* 
 * File:   main.cpp
 * Author: Mehak
 * Created on January 13, 2023, 6:05 PM
 * Purpose: Personal Information
 */

// System Libraries
#include <iostream> // Input Output Library 
using namespace std;

//User Libraries

//Global Constants not Variables
//Science, Math, Conversions, Dimensions

//Function Prototypes

//Execution begins here at main
int main(int argc, char** argv) {
    //Set random number seed
    
    //Declare Variables

    //Initialize Variables
    
    //Map/Process the inputs -> Outputs
    
    //Display Inputs/Outputs
    cout<<"Mehak Lohchan\n"<<"1234 Lane Riverside CA 12345\n"<<"123-456-7890\n"<<"Computer Science";
    
    //Clean up memory and files
    
    //Exit Program
    return 0;
}